import React from "react";

const Footer: React.FC<any> = () => {

  return (
    <>
  Footer
    </>
  );
};

export default Footer;
